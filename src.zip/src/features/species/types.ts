export interface FieldSource {
  source: string
  reference?: string | null
  retrieved_at?: string | null
  [key: string]: unknown
}

export interface Species {
  id: number
  scientific_name: string
  kingdom: string | null
  class_name: string | null
  order_name: string | null
  family: string | null
  genus: string | null
  species_epithet: string | null
  common_name: string | null
  raw_taxonomy_extra: Record<string, unknown> | null
  field_sources: Record<string, string | FieldSource | null> | null
  iucn_status: string | null
  iucn_trend: string | null
  national_status: string
  guild: string | null
  ecosystem_service: string | null
  habitat: string | null
  typology: string | null
  endemism: string | null
  potential_threats: string | null
  reference: string | null
  status: string
  created_by: number
  validated_by: number | null
  validated_at: string | null
  updated_at: string
}

export interface Page<T> {
  items: T[]
  total: number
  page: number
  page_size: number
  pages: number
}

export interface SpeciesLookupDraft {
  scientific_name: string
  input_scientific_name: string | null

  taxonomy: {
    kingdom?: string | null
    phylum?: string | null
    class_name?: string | null
    order_name?: string | null
    family?: string | null
    genus?: string | null
    species_epithet?: string | null
    common_name?: string | null
  }

  conservation: {
    iucn_status?: string | null
    iucn_trend?: string | null
    iucn_assessments?: IucnAssessment[]
  }

  traits: {
    guild?: string | null
    ecosystem_service?: string | null
    habitat?: string | null
    typology?: string | null
    endemism?: string | null
    potential_threats?: string | null
    reference?: string | null
  }

  field_sources: Record<string, string | FieldSource | null>
  national_status: string
}

export interface SpeciesCreateInput {
  scientific_name: string
  site_id: number
  kingdom?: string | null
  class_name?: string | null
  order_name?: string | null
  family?: string | null
  genus?: string | null
  species_epithet?: string | null
  common_name?: string | null
  field_sources?: Record<string, string | FieldSource | null> | null
  iucn_status?: string | null
  iucn_trend?: string | null
  guild?: string | null
  ecosystem_service?: string | null
  habitat?: string | null
  typology?: string | null
  endemism?: string | null
  potential_threats?: string | null
  reference?: string | null
}

export interface SpeciesUpdateInput {
  kingdom?: string | null
  class_name?: string | null
  order_name?: string | null
  family?: string | null
  genus?: string | null
  species_epithet?: string | null
  common_name?: string | null
  guild?: string | null
  ecosystem_service?: string | null
  habitat?: string | null
  typology?: string | null
  endemism?: string | null
  potential_threats?: string | null
  reference?: string | null
  iucn_status?: string | null
  iucn_trend?: string | null
  updated_at: string
}

export interface SpeciesFilters {
  search: string
  kingdom: string
  class_name: string
  order_name: string
  family: string
  genus: string
  national_status: string
  site_id: string
  iucn_status: string
}

export const EMPTY_SPECIES_FILTERS: SpeciesFilters = {
  search: '',
  kingdom: '',
  class_name: '',
  order_name: '',
  family: '',
  genus: '',
  national_status: '',
  site_id: '',
  iucn_status: '',

}

export interface ValidationHistoryEntry {
  id: number
  species_id: number
  action: string
  changed_fields: Record<string, unknown>
  validated_by: number
  validated_at: string
}

export interface DuplicateCheckResult {
  exists: boolean
  species?: Species
}

export interface IucnAssessment {
  assessment_id: number | string
  scope: 'Global' | 'Europe' | 'Mediterranean'
  scope_code?: string | null
  year: number | null
  category: string | null
  population_trend: string | null
}

export interface BatchSpeciesLookupItem {
  input_scientific_name: string
  draft: SpeciesLookupDraft | null
  duplicate: boolean
  existing_species?: Species | null
  error?: string | null
}

export interface BatchSpeciesLookupResponse {
  items: BatchSpeciesLookupItem[]
}

export interface BatchSpeciesLookupJobResponse {
  job_id: string
  status: 'queued' | 'running' | 'completed' | 'failed'
  total: number
  processed: number
  items: BatchSpeciesLookupItem[]
  started_at: string | null
  finished_at: string | null
  error: string | null
}